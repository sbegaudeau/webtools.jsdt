package p1.p2;

public @interface Annot2 {
	/**
	 * Description of name2
	 */
	String name2() default "";
}
