package p1.p2;

public abstract class TestClass {
	abstract void methodXXX( final Object prm1,
							 final Object prm2,
							 final Object prm3);

	void test() throws NullPointerException, IllegalArgumentException, IllegalStateException {
	}
}