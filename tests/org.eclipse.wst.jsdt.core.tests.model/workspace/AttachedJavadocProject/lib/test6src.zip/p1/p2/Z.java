package p1.p2;

import java.io.PrintStream;

/**
 * Description for class Z
 */
public class Z {
	
	/**
	 * Javadoc for field out
	 */
	public static PrintStream out;
	
	public static void foo() {}
	
	/**
	 * Prevent instanciation
	 */
	private Z() {}
	
	class D {}
	
	/**
	 * Package visible method foo
	 */
	int foo(int i, int j)  {
		return i + j;
	}
}
