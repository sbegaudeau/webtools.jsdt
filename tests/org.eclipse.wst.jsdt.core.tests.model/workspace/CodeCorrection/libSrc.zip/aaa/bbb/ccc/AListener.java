package aaa.bbb.ccc;

public interface AListener {
	public void foo();
}
