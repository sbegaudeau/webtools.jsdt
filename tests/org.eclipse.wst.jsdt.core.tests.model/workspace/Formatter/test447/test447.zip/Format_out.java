public class Format {

  private void temp() {
    return;
  }
}
