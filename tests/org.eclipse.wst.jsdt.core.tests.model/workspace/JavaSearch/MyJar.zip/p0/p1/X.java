package p0.p1;

public class X {

}

