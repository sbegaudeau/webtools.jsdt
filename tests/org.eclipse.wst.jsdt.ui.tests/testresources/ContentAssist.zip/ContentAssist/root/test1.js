function funcOne() {

}

function funcTwo() {
	return "";
}

function funcThree(paramOne) {
	
}

function funcFour(paramOne, paramTwo) {
	return paramOne * paramTwo;
}



fun

funcT