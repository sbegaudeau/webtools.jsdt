function MyClass1(a) {
    this.a = a;
}

var MyClass2 = function() {};
MyClass2.prototype.meth = function() {};

new MyCl