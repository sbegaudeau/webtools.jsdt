function MyClass7(a) {
    this.a = a;
}

var o = {
	a: new ,
	b: 42
};

var q = {
	a: new MyC,
	b: 42
};