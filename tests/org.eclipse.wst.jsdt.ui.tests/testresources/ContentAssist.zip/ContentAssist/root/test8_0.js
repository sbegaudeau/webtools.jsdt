org = {};
org.eclipse = {};
org.eclipse2 = {};
org.eclipse.fun = function(){};
org.eclipse.crazy = function() {};

org.