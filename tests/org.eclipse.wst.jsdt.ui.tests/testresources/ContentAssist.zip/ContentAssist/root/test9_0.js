var test = {};
test['Foo'] = function(x, y, z) {
	this.fX = x;
	this.fY = y;
	this.fZ = z;
};

new tes